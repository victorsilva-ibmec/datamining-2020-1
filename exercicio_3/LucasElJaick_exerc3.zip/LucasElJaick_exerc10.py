def exer10 ():
    vet1 = [1,2,3,4,5,6,7,8,9,10]
    vet2 = [11,12,13,14,15,16,17,18,19,20]
    vet3 = []
    for i in range(10):
	    vet3.append(vet1[i])
	    vet3.append(vet2[i])

    print(vet1)
    print(vet2)
    print(vet3)

def main():
    exer10()

main()